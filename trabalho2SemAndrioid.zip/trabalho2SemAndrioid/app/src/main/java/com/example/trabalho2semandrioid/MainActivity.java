package com.example.trabalho2semandrioid;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Variáveis com nomes informais
    private EditText caixaNome, caixaEmail, caixaIdade, caixaMateria, campoNota1, campoNota2;
    private Button botaoMandar, botaoApagar;
    private TextView telaResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os componentes
        caixaNome = findViewById(R.id.etNome);
        caixaEmail = findViewById(R.id.etEmail);
        caixaIdade = findViewById(R.id.etIdade);
        caixaMateria = findViewById(R.id.etDisciplina);
        campoNota1 = findViewById(R.id.etNota1);
        campoNota2 = findViewById(R.id.etNota2);
        botaoMandar = findViewById(R.id.btnEnviar);
        botaoApagar = findViewById(R.id.btnLimpar);
        telaResultado = findViewById(R.id.tvResultado);

        // Botão de Mandar (Enviar)
        botaoMandar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarCampos();
            }
        });

        // Botão de Apagar (Limpar)
        botaoApagar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparTudo();
            }
        });
    }

    // Função para validar o formulário
    private void validarCampos() {
        // Pegando os textos digitados
        String nomeDoAluno = caixaNome.getText().toString().trim();
        String emailDoAluno = caixaEmail.getText().toString().trim();
        String idadeDoAlunoStr = caixaIdade.getText().toString().trim();
        String materiaDoAluno = caixaMateria.getText().toString().trim();
        String notaUmStr = campoNota1.getText().toString().trim();
        String notaDoisStr = campoNota2.getText().toString().trim();

        // Verificando se os campos foram preenchidos certinho
        if (TextUtils.isEmpty(nomeDoAluno)) {
            telaResultado.setText("Ei! O campo Nome tá vazio.");
            return;
        }
        if (TextUtils.isEmpty(emailDoAluno) || !android.util.Patterns.EMAIL_ADDRESS.matcher(emailDoAluno).matches()) {
            telaResultado.setText("Ops! O campo Email tá vazio ou tá errado.");
            return;
        }
        if (TextUtils.isEmpty(idadeDoAlunoStr) || !idadeDoAlunoStr.matches("\\d+")) {
            telaResultado.setText("Idade tem que ser um número positivo, viu?");
            return;
        }
        int idadeDoAluno = Integer.parseInt(idadeDoAlunoStr);
        if (idadeDoAluno <= 0) {
            telaResultado.setText("A idade tem que ser maior que zero!");
            return;
        }
        if (TextUtils.isEmpty(materiaDoAluno)) {
            telaResultado.setText("Não esquece da Matéria!");
            return;
        }
        if (TextUtils.isEmpty(notaUmStr) || !notaValida(notaUmStr)) {
            telaResultado.setText("Ih! A Nota 1º Bimestre tá errada.");
            return;
        }
        if (TextUtils.isEmpty(notaDoisStr) || !notaValida(notaDoisStr)) {
            telaResultado.setText("Olha, a Nota 2º Bimestre não tá certa.");
            return;
        }

        // Convertendo as notas para calcular
        double notaUm = Double.parseDouble(notaUmStr);
        double notaDois = Double.parseDouble(notaDoisStr);
        double mediaDasNotas = (notaUm + notaDois) / 2;

        // Mostrando os dados legais
        String resultado = String.format("Nome: %s\nEmail: %s\nIdade: %d\nMatéria: %s\n" +
                        "Notas: %.2f e %.2f\nMédia: %.2f\n",
                nomeDoAluno, emailDoAluno, idadeDoAluno, materiaDoAluno, notaUm, notaDois, mediaDasNotas);

        // Aprovação ou Reprovação
        if (mediaDasNotas >= 6) {
            resultado += "Legal, você foi Aprovado!";
        } else {
            resultado += "Ah não, foi Reprovado.";
        }

        telaResultado.setText(resultado);
    }

    // Função para validar se a nota está no intervalo certo
    private boolean notaValida(String notaStr) {
        try {
            double nota = Double.parseDouble(notaStr);
            return nota >= 0 && nota <= 10;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // Função para limpar os campos
    private void limparTudo() {
        caixaNome.setText("");
        caixaEmail.setText("");
        caixaIdade.setText("");
        caixaMateria.setText("");
        campoNota1.setText("");
        campoNota2.setText("");
        telaResultado.setText("");
    }
}